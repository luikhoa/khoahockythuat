const fs = require("fs");
global.fetch = async (p) => ({ json: async () => JSON.parse(fs.readFileSync(p, "utf8")) });
const M = require("../extension/classifier.js");
(async () => {
  const meta = await M.load("../extension/model.json");
  console.log("Mô hình:", meta["phương_án"], "| macro-F1 CV =", meta.macro_f1_cv);
  const demo = ["mai ra cổng trường tao đánh cho một trận",
                "m ngu như bò ấy",
                "ê thằng điên này quên vở nữa rồi hahaha",
                "ai có đáp án bài 5 ko cho mk xin vs"];
  for (const t of demo) {
    const r = M.predict(t);
    console.log(`  [${r.name.padEnd(9)} ${r.confidence.toFixed(3)}]  ${t}`);
  }
})();
