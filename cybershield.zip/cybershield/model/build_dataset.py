# -*- coding: utf-8 -*-
"""
build_dataset.py — Tạo bộ dữ liệu MẪU để chạy thử toàn bộ pipeline.

QUAN TRỌNG: Đây KHÔNG phải dữ liệu nghiên cứu thật.
Nhóm phải thay bằng dữ liệu do chính học sinh thu thập và gán nhãn
(xem hướng dẫn trong README, mục "Thay dữ liệu thật").

Nhãn:
  0 = an toàn          (bình thường, kể cả teencode / trêu đùa thân thiện)
  1 = xúc phạm         (chửi bới, miệt thị, hạ nhục)
  2 = đe dọa / bạo lực (dọa đánh, dọa bóc phốt, xúi tự hại)
"""
import csv
import itertools
import random
from pathlib import Path

random.seed(42)
OUT = Path(__file__).resolve().parent.parent / "data" / "dataset.csv"

# ---------------------------------------------------------------- an toàn (0)
SAFE = [
    "hôm nay đi học vui ghê",
    "ai có đáp án bài 5 trang 42 ko cho mk xin vs",
    "video này hay quá ạ",
    "trời ơi cute xỉu",
    "ê mai đi ăn chè hong",
    "mng cho e hỏi đề cương thi giữa kì có chưa ạ",
    "ok bạn nhé cảm ơn nhiều",
    "t buồn ngủ quá đi mất",
    "bài này khó vãi nhưng cố lên nào",
    "chúc mừng sinh nhật cậu nha",
    "ê thằng điên này lại quên mang vở nữa rồi hahaha",
    "con gà này đá bóng dở tệ mà vẫn cứ đòi ra sân, thương",
    "mày ngốc thật đấy nhưng mà dễ thương",
    "ơ kìa ông tướng, dậy đi học chưa",
    "xàm quá đi mất, cười ỉa",
    "u là trời, đỉnh nóc kịch trần",
    "cái áo này đẹp mà, mua ở đâu z",
    "hôm nay cô kiểm tra miệng, xin vía qua môn",
    "nay ai trực nhật vậy mn",
    "team mình họp lúc mấy giờ nhỉ",
    "cho mình mượn cục tẩy với",
    "phim này xem được đó, 8 điểm",
    "mai nghỉ học đúng ko mn ơi",
    "ăn cơm chưa, nhớ ăn đủ bữa nha",
    "cố lên nha, sắp thi rồi",
    "mình vừa được 9 điểm toán nè",
    "chụp ảnh xấu quá, xoá đi",
    "thời tiết nay mát ghê",
    "ai chơi game với t ko",
    "link tài liệu đây nha mn",
    "bạn giải thích giúp mình câu này được ko",
    "ừa để tí t gửi",
    "hôm nay mệt thật sự luôn",
    "nhóm mình làm phần nào rồi ạ",
    "thôi bỏ qua đi, không có gì đâu",
    "sao nay lớp vắng thế nhỉ",
    "ê bà kia, để dành cho tui miếng bánh",
    "trời đánh, quên làm bài tập",
    "ảo thật đấy, không tin nổi",
    "đi thôi mấy má, muộn rồi",
]

# ------------------------------------------------------------- xúc phạm (1)
OFFENSIVE = [
    "mày ngu như bò ấy, học mãi ko vô",
    "nhìn mặt mày ghét vãi",
    "im mồm đi thằng ngu",
    "óc chó thì đừng có phát biểu",
    "xấu như ma còn bày đặt chụp ảnh",
    "loại rác rưởi như mày biến đi",
    "câm mồm lại, nghe mà ngứa tai",
    "đồ vô dụng, chả làm được cái gì",
    "nhìn cái mặt là biết học dốt rồi",
    "mày là đồ bỏ đi, ai chơi với mày",
    "béo như lợn còn đòi mặc đồ đẹp",
    "thứ ngu dốt, đừng có nói chuyện với tao",
    "loại như mày sinh ra làm gì cho phí",
    "nghèo mà bày đặt đú đởn",
    "cút khỏi group đi, ai mời mày vào",
    "vô duyên kinh khủng, ai chịu nổi",
    "đồ hai mặt, ghê tởm",
    "mày mà cũng đòi làm nhóm trưởng à, buồn cười",
    "học dốt còn nói nhiều, nhục",
    "nhìn phát ói, đừng đăng ảnh nữa",
    "thằng nhà quê, ăn mặc như ăn xin",
    "bố mẹ mày ko dạy à",
    "đồ ăn hại, làm gì cũng hỏng",
    "mày bị thần kinh à mà nói chuyện kiểu đó",
    "loại con gái mất nết",
    "ngu thì chết chứ bệnh tật gì",
    "đừng có sủa nữa được ko",
    "mặt dày vãi, ai thèm quan tâm",
    "đồ ngốc nghếch vô dụng, ở nhà đi",
    "nhìn thấy mày là thấy xui",
]

# ------------------------------------------------------- đe doạ / bạo lực (2)
THREAT = [
    "mai ra cổng trường tao đánh cho một trận",
    "liệu hồn mà đi học một mình nhé",
    "tao mà gặp là mày ăn đòn đấy",
    "chờ đấy, tao cho mày biết tay",
    "tao bóc phốt hết ảnh của mày lên đây giờ",
    "mày mà nói nữa là tao cho cả lớp tẩy chay",
    "tao có ảnh của mày, đừng có làm tao điên",
    "hẹn mày sau giờ học, đừng có trốn",
    "tụi tao đợi mày ở cổng sau đó",
    "mai lên lớp là biết tay tao",
    "tao đăng hết tin nhắn riêng của mày lên nhóm giờ",
    "đừng để tao thấy mặt mày ở trường nữa",
    "tao kêu anh tao xử mày",
    "mày mà mách cô là chết với tao",
    "cả lớp nghỉ chơi với nó đi, ai chơi tao xử luôn",
    "tao biết nhà mày ở đâu đấy, liệu hồn",
    "sống làm gì cho chật đất, biến mất đi",
    "mày biến mất khỏi thế giới này đi cho rồi",
    "tao chặn đường mày cho biết mặt",
    "chuẩn bị tinh thần đi nhé, chưa xong đâu",
]

# --------------------------------------------- biến thể teencode / né bộ lọc
def variants(s: str):
    """Sinh biến thể viết tắt, chèn ký tự, lặp ký tự — mô phỏng cách né bộ lọc."""
    out = {s}
    rep = [("không", "ko"), ("được", "dc"), ("mày", "m"), ("tao", "t"),
           ("gì", "j"), ("rồi", "r"), ("với", "vs"), ("quá", "wa"),
           ("biết", "bit"), ("người", "ng"), ("anh", "a")]
    a = s
    for k, v in rep:
        a = a.replace(k, v)
    out.add(a)
    # chèn ký tự vào giữa từ nhạy cảm (kiểu n.g.u, ng*u)
    for w in ["ngu", "óc chó", "câm", "cút", "đánh", "xấu"]:
        if w in s:
            out.add(s.replace(w, ".".join(w)))
            out.add(s.replace(w, w[0] + "*" + w[1:]))
    # lặp ký tự cuối
    out.add(s + "!!!")
    out.add(s.replace(" ", "  ").strip())
    return out


rows = []
for gid, (text, label) in enumerate(itertools.chain(
    ((t, 0) for t in SAFE),
    ((t, 1) for t in OFFENSIVE),
    ((t, 2) for t in THREAT),
)):
    # group = id câu gốc. Mọi biến thể của cùng một câu phải nằm cùng một fold,
    # nếu không sẽ bị rò rỉ dữ liệu và điểm số ảo (F1 = 1.000).
    for v in variants(text):
        rows.append((v, label, gid))

# khử trùng lặp, xáo trộn
seen, uniq = set(), []
for t, l, g in rows:
    key = t.strip().lower()
    if key and key not in seen:
        seen.add(key)
        uniq.append((t.strip(), l, g))
random.shuffle(uniq)

OUT.parent.mkdir(parents=True, exist_ok=True)
with OUT.open("w", encoding="utf-8", newline="") as f:
    w = csv.writer(f)
    w.writerow(["text", "label", "group"])
    w.writerows(uniq)

from collections import Counter
c = Counter(l for _, l, _g in uniq)
print(f"Đã ghi {len(uniq)} dòng vào {OUT}")
print(f"  an toàn (0): {c[0]}\n  xúc phạm (1): {c[1]}\n  đe doạ (2): {c[2]}")
